// Hermes Hub - Content Script for Google Forms DOM Automation

(function () {
  // Prevent duplicate script registration
  if (window.__hermeshub_initialized) return;
  window.__hermeshub_initialized = true;

  // 1. Direct page keyboard listener for Ctrl+Shift+Y / Cmd+Shift+Y
  window.addEventListener("keydown", (e) => {
    const isY = e.key === "Y" || e.key === "y" || e.code === "KeyY";
    const hasModifier = (e.ctrlKey || e.metaKey) && e.shiftKey;
    if (hasModifier && isY) {
      e.preventDefault();
      executeQuizSolving();
    }
  });

  // 2. Extension message listener (from background script or popup)
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "TRIGGER_SOLVE") {
      executeQuizSolving();
      sendResponse({ status: "started" });
    }
  });

  /**
   * Main solving workflow
   */
  async function executeQuizSolving() {
    const indicator = createStatusIndicator();
    indicator.update("Scanning questions...", "loading");

    try {
      // 1. Scrape question elements from the form
      const questionsData = extractFormQuestions();

      if (!questionsData || questionsData.length === 0) {
        throw new Error("No questions found. Make sure this is a Google Form in view mode.");
      }

      indicator.update(`Found ${questionsData.length} question(s). Solving...`, "loading");

      // 2. Prepare payload for AI solver
      const payload = questionsData.map((q) => ({
        index: q.index,
        type: q.type,
        question: q.questionText,
        // Google Forms may place important instructions or context in a separate
        // question-description element. Keep it separate in the payload so the
        // AI can interpret it together with the question title.
        description: q.descriptionText || "",
        options: q.options.map((opt) => opt.text)
      }));

      // 3. Send payload to background script
      const response = await chrome.runtime.sendMessage({
        action: "SOLVE_FORM_QUESTIONS",
        questions: payload
      });

      if (!response || !response.success) {
        throw new Error(response?.error || "Failed to receive answers from AI API.");
      }

      // 4. Fill in answers
      indicator.update("Filling answers...", "loading");
      const filledCount = await applyAnswersToDOM(questionsData, response.answers);

      // 5. Success feedback
      indicator.update(`Filled ${filledCount}/${questionsData.length} questions ✓`, "success");
      setTimeout(() => indicator.remove(), 600);
    } catch (err) {
      console.error("[Hermes Hub]", err);
      indicator.update(`Error: ${err.message}`, "error");
      setTimeout(() => indicator.remove(), 1500);
    }
  }

  /**
   * Discreet Status Indicator: three faint pulsing dots, no text, no background.
   * Same position as before (bottom-left). The text passed to update() is ignored.
   */
  function createStatusIndicator() {
    // Clean up any existing indicator
    const existing = document.getElementById("hermeshub-indicator-container");
    if (existing) existing.remove();

    const styleId = "hermeshub-indicator-style";
    const oldStyle = document.getElementById(styleId);
    if (oldStyle) oldStyle.remove();

    const style = document.createElement("style");
    style.id = styleId;
    style.textContent = `
      @keyframes hermeshub-dot {
        0%, 80%, 100% { opacity: 0.25; transform: translateY(0); }
        40% { opacity: 1; transform: translateY(-2px); }
      }
      #hermeshub-indicator-container {
        position: fixed !important;
        bottom: 12px !important;
        left: 12px !important;
        display: flex !important;
        align-items: center !important;
        gap: 4px !important;
        padding: 0 !important;
        background: none !important;
        border: none !important;
        box-shadow: none !important;
        z-index: 9999999 !important;
        pointer-events: none !important;
        opacity: 0.3 !important;
        transition: opacity 0.4s ease !important;
      }
      #hermeshub-indicator-container.hh-hide {
        opacity: 0 !important;
      }
      .hermeshub-dot {
        width: 5px !important;
        height: 5px !important;
        border-radius: 50% !important;
        background: #6b7280 !important;
        animation: hermeshub-dot 1.2s ease-in-out infinite !important;
      }
      .hermeshub-dot:nth-child(2) { animation-delay: 0.15s !important; }
      .hermeshub-dot:nth-child(3) { animation-delay: 0.3s !important; }
      #hermeshub-indicator-container.error .hermeshub-dot {
        background: #ef4444 !important;
      }
    `;
    document.head.appendChild(style);

    const container = document.createElement("div");
    container.id = "hermeshub-indicator-container";
    for (let i = 0; i < 3; i++) {
      const dot = document.createElement("span");
      dot.className = "hermeshub-dot";
      container.appendChild(dot);
    }
    document.body.appendChild(container);

    return {
      // Text is intentionally ignored; only the state (loading / success / error) matters.
      update(_text, state = "loading") {
        container.classList.toggle("error", state === "error");
      },
      remove() {
        container.classList.add("hh-hide");
        setTimeout(() => container.remove(), 450);
      }
    };
  }

  /**
   * Scrapes question blocks and their corresponding options
   */
  function extractFormQuestions() {
    // Google Forms uses several question card classes across different versions
    let items = Array.from(document.querySelectorAll('div[role="listitem"]'));

    if (items.length === 0) {
      items = Array.from(document.querySelectorAll('.Qr7Oae, .geS5n, div[data-item-id]'));
    }

    // Fallback: search headings and get parent card
    if (items.length === 0) {
      const headings = Array.from(document.querySelectorAll('div[role="heading"], .M7eMe'));
      const cardSet = new Set();
      headings.forEach((h) => {
        const card = h.closest('.Qr7Oae, .geS5n, div[jsmodel], div[data-params]');
        if (card) cardSet.add(card);
      });
      items = Array.from(cardSet);
    }

    const questions = [];

    items.forEach((item, index) => {
      // 1. Question title/prompt
      const headingEl = item.querySelector('div[role="heading"], .M7eMe, .HoXoMd');
      let questionText = getCleanText(headingEl);

      // Fallback text if heading missing
      if (!questionText) {
        const textElements = Array.from(item.querySelectorAll('span[dir="auto"], div[dir="auto"]'));
        if (textElements.length > 0) {
          questionText = getCleanText(textElements[0]);
        }
      }

      if (!questionText) return; // Skip non-question cards

      // 2. Question description/instructions. Google Forms commonly renders
      // these separately from the title (for example, in .gubaDc). Descriptions
      // can contain passages, conditions, or instructions needed to answer.
      const descriptionText = extractQuestionDescription(item, headingEl);

      // 2. Multiple Choice (Radio)
      const radioElements = Array.from(item.querySelectorAll('[role="radio"]'));
      if (radioElements.length > 0) {
        const options = radioElements.map((radio) => ({
          text: getOptionLabel(radio),
          element: radio
        })).filter((opt) => opt.text.length > 0);

        questions.push({
          index,
          itemElement: item,
          type: "multiple_choice",
          questionText,
          descriptionText,
          options
        });
        return;
      }

      // 3. Checkboxes
      const checkboxElements = Array.from(item.querySelectorAll('[role="checkbox"]'));
      if (checkboxElements.length > 0) {
        const options = checkboxElements.map((cb) => ({
          text: getOptionLabel(cb),
          element: cb
        })).filter((opt) => opt.text.length > 0);

        questions.push({
          index,
          itemElement: item,
          type: "checkboxes",
          questionText,
          descriptionText,
          options
        });
        return;
      }

      // 4. Dropdown Listbox
      const listbox = item.querySelector('[role="listbox"]');
      if (listbox) {
        const optionEls = Array.from(item.querySelectorAll('[role="option"]'));
        const options = optionEls.map((opt) => ({
          text: opt.innerText.trim() || opt.getAttribute("data-value") || "",
          element: opt
        })).filter((o) => o.text && !o.text.toLowerCase().includes("choose"));

        questions.push({
          index,
          itemElement: item,
          type: "dropdown",
          questionText,
          descriptionText,
          options,
          listboxElement: listbox
        });
        return;
      }

      // 5. Short Answer / Paragraph Text
      const textarea = item.querySelector("textarea");
      if (textarea) {
        questions.push({
          index,
          itemElement: item,
          type: "paragraph",
          questionText,
          descriptionText,
          options: [],
          inputElement: textarea
        });
        return;
      }

      const textInput = item.querySelector('input[type="text"]:not([style*="display: none"])');
      if (textInput) {
        questions.push({
          index,
          itemElement: item,
          type: "short_answer",
          questionText,
          descriptionText,
          options: [],
          inputElement: textInput
        });
        return;
      }
    });

    return questions;
  }

  /**
   * Returns readable text without excess whitespace or blank lines.
   */
  function getCleanText(element) {
    if (!element) return "";
    return String(element.innerText || element.textContent || "")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]+\n/g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  /**
   * Reads a Google Forms question's separate description/instructions.
   * The title and answer choices are deliberately excluded from this field.
   */
  function extractQuestionDescription(item, headingEl) {
    const candidates = new Set();

    // .gubaDc is the common Google Forms question-description class.
    // The data attributes and role=note selectors provide fallbacks for
    // alternate/updated form markup.
    item.querySelectorAll(
      '.gubaDc, [data-question-description], [data-description], [role="note"]'
    ).forEach((element) => candidates.add(element));

    // Some versions expose the description through the heading's
    // aria-describedby relationship instead of a stable CSS class.
    const describedBy = [
      headingEl && headingEl.getAttribute("aria-describedby"),
      item.getAttribute("aria-describedby")
    ].filter(Boolean).join(" ").split(/\s+/).filter(Boolean);

    describedBy.forEach((id) => {
      const target = document.getElementById(id);
      if (target && item.contains(target)) candidates.add(target);
    });

    const titleText = getCleanText(headingEl);
    const descriptions = [];
    const seen = new Set();

    candidates.forEach((element) => {
      if (!element || element === headingEl) return;
      if (headingEl && (headingEl.contains(element) || element.contains(headingEl))) return;

      const style = window.getComputedStyle(element);
      if (style.display === "none" || style.visibility === "hidden") return;

      const text = getCleanText(element);
      if (!text || text === titleText || seen.has(text)) return;
      seen.add(text);
      descriptions.push(text);
    });

    return descriptions.join("\n\n");
  }

  /**
   * Helper to retrieve clean label text for a radio/checkbox option
   */
  function getOptionLabel(controlElement) {
    // Attribute check
    const ariaLabel = controlElement.getAttribute("aria-label");
    if (ariaLabel && ariaLabel.trim()) return ariaLabel.trim();

    const dataValue = controlElement.getAttribute("data-value");
    if (dataValue && dataValue.trim()) return dataValue.trim();

    // Container check
    const row = controlElement.closest('.docssharedWizToggleLabeledContainer, .Od2TWd, .SG0Aua, label') || controlElement.parentElement;
    if (row) {
      const textSpan = row.querySelector('.aDTYNe, .s392dd, span[dir="auto"], .OvPDhc');
      if (textSpan && textSpan.innerText.trim()) {
        return textSpan.innerText.trim();
      }
      return row.innerText.trim();
    }

    return "";
  }

  /**
   * Simulates full mouse and pointer events for Google Forms components
   */
  function simulateClick(element) {
    if (!element) return;

    const eventOpts = { bubbles: true, cancelable: true, view: window };
    element.dispatchEvent(new PointerEvent("pointerdown", eventOpts));
    element.dispatchEvent(new MouseEvent("mousedown", eventOpts));
    element.dispatchEvent(new PointerEvent("pointerup", eventOpts));
    element.dispatchEvent(new MouseEvent("mouseup", eventOpts));
    element.click();

    // Fallback: If aria-checked is still false, trigger the parent row wrapper
    setTimeout(() => {
      if (element.getAttribute("aria-checked") !== "true") {
        const parentRow = element.closest('.docssharedWizToggleLabeledContainer, .Od2TWd, .SG0Aua, label');
        if (parentRow && parentRow !== element) {
          parentRow.click();
        }
      }
    }, 40);
  }

  /**
   * Simulates typing into Google Forms text input and dispatches framework events
   */
  function simulateTextInput(inputEl, text) {
    if (!inputEl) return;
    inputEl.focus({ preventScroll: true });
    inputEl.value = text;

    inputEl.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
    inputEl.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));

    try {
      inputEl.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        cancelable: true,
        inputType: "insertText",
        data: text
      }));
    } catch (_) {}

    inputEl.dispatchEvent(new Event("blur", { bubbles: true, cancelable: true }));
  }

  /**
   * Freezes scroll position (window + scrollable ancestors of the form) so that
   * clicking / focusing answers never moves the page. Returns a release() function.
   */
  function lockScroll(anchorEl) {
    const targets = [];
    const seen = new Set();
    const add = (el) => {
      if (!el || seen.has(el)) return;
      seen.add(el);
      targets.push({ el, top: el.scrollTop, left: el.scrollLeft });
    };

    add(document.scrollingElement || document.documentElement);
    add(document.body);
    for (let el = anchorEl; el && el !== document.documentElement; el = el.parentElement) {
      const oy = getComputedStyle(el).overflowY;
      if (el.scrollHeight > el.clientHeight && /(auto|scroll|overlay)/.test(oy)) add(el);
    }

    const restore = () => {
      for (const t of targets) {
        if (t.el.scrollTop !== t.top) t.el.scrollTop = t.top;
        if (t.el.scrollLeft !== t.left) t.el.scrollLeft = t.left;
      }
    };

    // Capture phase: scroll events don't bubble, but they do get captured at document/window
    window.addEventListener("scroll", restore, true);

    return function release() {
      // Keep guarding briefly: Forms may scroll asynchronously after the last click
      setTimeout(() => {
        restore();
        window.removeEventListener("scroll", restore, true);
      }, 500);
    };
  }

  /**
   * Applies the solved answers into the DOM
   */
  async function applyAnswersToDOM(questionsData, aiAnswers) {
    if (!Array.isArray(aiAnswers)) return 0;
    let filled = 0;
    const releaseScroll = lockScroll(questionsData[0] && questionsData[0].itemElement);

    try {
    for (const ansItem of aiAnswers) {
      const q = questionsData.find((qData) => qData.index === ansItem.index);
      if (!q) continue;

      const targetAnswers = Array.isArray(ansItem.answers) ? ansItem.answers : [ansItem.answers];

      if (q.type === "multiple_choice" || q.type === "checkboxes") {
        let matchedAny = false;
        for (const targetText of targetAnswers) {
          if (!targetText) continue;
          const match = findBestMatchingOption(q.options, targetText);
          if (match && match.element) {
            const isChecked = match.element.getAttribute("aria-checked") === "true";
            if (!isChecked) {
              simulateClick(match.element);
              matchedAny = true;
            } else {
              matchedAny = true;
            }
          }
        }
        if (matchedAny) filled++;
      } else if (q.type === "dropdown") {
        for (const targetText of targetAnswers) {
          const match = findBestMatchingOption(q.options, targetText);
          if (match && match.element) {
            if (q.listboxElement) {
              simulateClick(q.listboxElement);
              await new Promise((r) => setTimeout(r, 80));
            }
            simulateClick(match.element);
            filled++;
          }
        }
      } else if (q.type === "short_answer" || q.type === "paragraph") {
        if (q.inputElement && targetAnswers.length > 0) {
          simulateTextInput(q.inputElement, String(targetAnswers[0]));
          filled++;
        }
      }

      await new Promise((r) => setTimeout(r, 50));
    }
    } finally {
      releaseScroll();
    }

    return filled;
  }

  /**
   * Robust option matcher
   */
  function findBestMatchingOption(options, target) {
    if (!options || options.length === 0 || !target) return null;

    const clean = (str) =>
      String(str)
        .toLowerCase()
        .replace(/^[a-z0-9][\.\)\-\:]\s*/i, "") // Strip leading "A.", "1)", etc.
        .replace(/[\r\n\t]/g, " ")
        .trim();

    const targetClean = clean(target);

    // 1. Exact match on cleaned text
    let matched = options.find((opt) => clean(opt.text) === targetClean);
    if (matched) return matched;

    // 2. Contains match
    matched = options.find((opt) => {
      const optClean = clean(opt.text);
      return optClean.includes(targetClean) || targetClean.includes(optClean);
    });

    return matched || null;
  }
})();

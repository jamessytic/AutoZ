// Hermes Hub - Background Service Worker (Manifest V3)

const HERMES_GATEWAY_URL = "https://hermes-ai-gateway.202580215.workers.dev";

/**
 * Global Keyboard Command Listener
 */
chrome.commands.onCommand.addListener(async (command) => {
  if (command === "solve-form") {
    triggerSolveOnActiveTab();
  }
});

/**
 * Message Listener for actions from content script or popup
 */
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // Trigger from popup button
  if (request.action === "POPUP_TRIGGER_SOLVE") {
    triggerSolveOnActiveTab()
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  // Fetch available models for an API key
  if (request.action === "FETCH_AVAILABLE_MODELS") {
    listAvailableModels(request.provider, request.apiKey)
      .then((models) => sendResponse({ success: true, models }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  // AI solve request from content script
  if (request.action === "SOLVE_FORM_QUESTIONS") {
    handleSolveQuestions(request.questions)
      .then((result) => sendResponse({ success: true, answers: result }))
      .catch((error) => sendResponse({ success: false, error: error.message }));
    return true; // Keep message channel open for async fetch
  }
});

/**
 * Triggers solving on the currently active Google Forms tab
 */
async function triggerSolveOnActiveTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab || !tab.id) {
      throw new Error("No active tab detected.");
    }

    const tabUrl = tab.url || tab.pendingUrl || "";
    if (!tabUrl.includes("docs.google.com/forms")) {
      throw new Error("The active tab is not a Google Form (must be on docs.google.com/forms).");
    }

    // Try sending message to existing content script
    try {
      await chrome.tabs.sendMessage(tab.id, { action: "TRIGGER_SOLVE" });
      return { success: true };
    } catch (_) {
      // Content script not loaded yet (e.g. page was opened before extension installation)
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      await new Promise((r) => setTimeout(r, 100));
      await chrome.tabs.sendMessage(tab.id, { action: "TRIGGER_SOLVE" });
      return { success: true };
    }
  } catch (error) {
    console.error("[Hermes Hub Background]", error);
    return { success: false, error: error.message };
  }
}

/**
 * Provider registry. Gemini uses its own REST format; the rest are OpenAI-compatible.
 */
const PROVIDERS = {
  gemini: {
    label: "Gemini",
    defaultModel: "gemini-2.5-flash",
    prefer: ["3.8-flash", "3.6-flash", "3.5-flash-lite", "2.5-flash", "flash"]
  },
  groq: {
    label: "Groq",
    base: "https://api.groq.com/openai/v1",
    defaultModel: "llama-3.3-70b-versatile",
    prefer: ["llama-3.3-70b-versatile", "gpt-oss-120b", "llama-3.1-8b-instant"],
    exclude: /whisper|tts|guard|playai|orpheus|embed/i
  },
  openrouter: {
    label: "OpenRouter",
    base: "https://openrouter.ai/api/v1",
    defaultModel: "meta-llama/llama-3.3-70b-instruct:free",
    prefer: ["llama-3.3-70b-instruct:free", "gpt-oss-120b:free", "gemini", "llama"],
    onlyFree: true
  },
  cerebras: {
    label: "Cerebras",
    base: "https://api.cerebras.ai/v1",
    defaultModel: "llama-3.3-70b",
    prefer: ["llama-3.3-70b", "gpt-oss-120b", "llama"],
    exclude: /embed/i
  }
};

function pickPreferred(provider, models) {
  const cfg = PROVIDERS[provider];
  for (const key of cfg.prefer || []) {
    const hit = models.find((m) => m.includes(key));
    if (hit) return hit;
  }
  return models[0];
}

/**
 * Lists usable chat models for a provider + key
 */
async function listAvailableModels(provider = "gemini", apiKey) {
  const cfg = PROVIDERS[provider];
  if (!cfg) throw new Error(`Unknown provider: ${provider}`);
  if (!apiKey) return [];

  if (provider === "gemini") {
    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey)}`;
    const resp = await fetch(endpoint);
    if (!resp.ok) throw new Error(`Failed to list models: HTTP ${resp.status}`);
    const data = await resp.json();
    return (data?.models || [])
      .filter((m) => m.supportedGenerationMethods && m.supportedGenerationMethods.includes("generateContent"))
      .map((m) => m.name.replace(/^models\//, ""));
  }

  const resp = await fetch(`${cfg.base}/models`, {
    headers: { Authorization: `Bearer ${apiKey}` }
  });
  if (!resp.ok) throw new Error(`Failed to list models: HTTP ${resp.status}`);
  const data = await resp.json();
  let ids = (data?.data || []).map((m) => m.id).filter(Boolean);
  if (cfg.exclude) ids = ids.filter((id) => !cfg.exclude.test(id));
  if (cfg.onlyFree) ids = ids.filter((id) => id.endsWith(":free"));
  return ids.sort();
}

/**
 * Pulls a JSON array out of whatever the model returned
 * (handles code fences, <think> blocks, surrounding prose, and {"answers":[...]} wrappers).
 */
function parseModelJson(rawText) {
  let text = String(rawText)
    .replace(/<think>[\s\S]*?<\/think>/gi, "")
    .replace(/```json/gi, "")
    .replace(/```/g, "")
    .trim();

  const attempts = [text];
  const a = text.indexOf("["), b = text.lastIndexOf("]");
  if (a !== -1 && b > a) attempts.push(text.slice(a, b + 1));
  const c = text.indexOf("{"), d = text.lastIndexOf("}");
  if (c !== -1 && d > c) attempts.push(text.slice(c, d + 1));

  for (const t of attempts) {
    try {
      let parsed = JSON.parse(t);
      if (!Array.isArray(parsed) && parsed && typeof parsed === "object") {
        const arr = Object.values(parsed).find(Array.isArray);
        if (arr) parsed = arr;
      }
      if (Array.isArray(parsed)) return parsed;
    } catch (_) {}
  }
  throw new Error("unparseable");
}

/**
 * Sends the prompt to the chosen provider and returns the raw text reply
 */
async function callProvider(provider, apiKey, model, prompt) {
  if (provider === "gemini") {
    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;
    return fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: { responseMimeType: "application/json" }
      })
    });
  }
  return fetch(`${PROVIDERS[provider].base}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model,
      temperature: 0,
      messages: [
        { role: "system", content: "You are an expert quiz solver. Reply with ONLY a JSON array, no commentary." },
        { role: "user", content: prompt }
      ]
    })
  });
}

function extractText(provider, data) {
  if (provider === "gemini") return data?.candidates?.[0]?.content?.parts?.[0]?.text;
  return data?.choices?.[0]?.message?.content;
}

/**
 * Uses the secure Cloudflare gateway. The API key never enters the extension.
 */
async function callHermesGateway(code, questions) {
  let response;
  try {
    response = await fetch(`${HERMES_GATEWAY_URL}/solve`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      cache: "no-store",
      credentials: "omit",
      body: JSON.stringify({ code, questions })
    });
  } catch (error) {
    throw new Error(`Could not connect to the Hermes AI gateway. Check your internet connection and Worker deployment. ${error.message || ""}`.trim());
  }

  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.success) {
    throw new Error(result.error || `Hermes gateway request failed (HTTP ${response.status}).`);
  }
  if (!Array.isArray(result.answers)) {
    throw new Error("Hermes gateway returned an invalid answer format.");
  }
  return result.answers;
}

/**
 * Queries the selected AI provider with the extracted questions
 */
async function handleSolveQuestions(questions) {
  const config = await chrome.storage.local.get(["provider", "keys", "models", "apiKey", "model", "managedCode"]);

  // In managed mode the provider key stays on Cloudflare. Only the code and questions are sent.
  if (config.managedCode) {
    return callHermesGateway(config.managedCode, questions);
  }

  const provider = PROVIDERS[config.provider] ? config.provider : "gemini";
  const label = PROVIDERS[provider].label;

  // Per-provider key/model, with fallback to the legacy single-key storage (Gemini)
  const apiKey = config.keys?.[provider] || (provider === "gemini" ? config.apiKey : "");
  let model =
    config.models?.[provider] ||
    (provider === "gemini" ? config.model : "") ||
    PROVIDERS[provider].defaultModel;

  if (!apiKey) {
    throw new Error(`API key is not configured! Click the extension icon and paste your ${label} API key.`);
  }

  const prompt = `You are an expert quiz solver. You are given questions extracted from a Google Form.
Each question object may contain both a "question" field (the visible question title) and a
"description" field (additional context, instructions, a passage, or conditions displayed
with that question). ALWAYS read and use BOTH fields together as one complete question.
A description is not optional page decoration: it may contain information required to
answer correctly, and it can change how the question should be interpreted. Do not ignore it.
If the description is empty, answer using the question title and options as usual.

CRITICAL RULES:
1. For choice-based questions (multiple_choice, checkboxes, dropdown): You MUST select strictly from the provided 'options' list. The answer string must match the chosen option text EXACTLY.
2. For multiple_choice and dropdown: Return exactly one answer string in the "answers" array.
3. For checkboxes: Return all correct answer strings in the "answers" array.
4. For short_answer / paragraph: Return a concise, accurate answer string in the "answers" array.
5. Use any relevant facts, constraints, or instructions in the question description when deciding the answer.
6. If unsure, choose the single most plausible option.
7. Output MUST be ONLY valid JSON matching the format below, without markdown formatting.

Questions to solve:
${JSON.stringify(questions, null, 2)}

Expected JSON output format:
[
  {
    "index": 0,
    "answers": ["Exact matching option text"]
  }
]`;

  let response = await callProvider(provider, apiKey, model, prompt);

  // Model missing/unsupported: discover what this key can use and retry once
  if (!response.ok && (response.status === 404 || response.status === 400 || response.status === 410)) {
    console.warn(`[Hermes Hub] Model '${model}' failed (${response.status}). Querying available models...`);
    try {
      const available = await listAvailableModels(provider, apiKey);
      const fallback = available.length ? pickPreferred(provider, available) : null;
      if (fallback && fallback !== model) {
        console.log(`[Hermes Hub] Retrying with available model: ${fallback}`);
        model = fallback;
        const models = { ...(config.models || {}), [provider]: fallback };
        chrome.storage.local.set({ models });
        response = await callProvider(provider, apiKey, model, prompt);
      }
    } catch (listErr) {
      console.error("[Hermes Hub] Failed to auto-discover models:", listErr);
    }
  }

  if (!response.ok) {
    let errorDetail = `HTTP ${response.status} (${response.statusText})`;
    try {
      const errJson = await response.json();
      const msg = errJson?.error?.message || errJson?.message;
      if (msg) errorDetail = msg;
    } catch (_) {}
    if (response.status === 429) {
      errorDetail = `Rate limit hit (free tier). Wait a minute and try again. ${errorDetail}`;
    }
    throw new Error(`${label} API Error: ${errorDetail}`);
  }

  const data = await response.json();
  const rawText = extractText(provider, data);

  if (!rawText) {
    throw new Error(`No answer returned by ${label} API.`);
  }

  try {
    return parseModelJson(rawText);
  } catch (_) {
    console.error("[Hermes Hub] JSON parse failure. Raw text:", rawText);
    throw new Error("AI returned an unparseable response format.");
  }
}

// Hermes Hub - Popup Settings Script
const GATEWAY_URL = "https://hermes-ai-gateway.202580215.workers.dev";

const PROVIDER_UI = {
  groq: {
    label: "Groq",
    placeholder: "gsk_...",
    link: "https://console.groq.com/keys",
    defaultModel: "llama-3.3-70b-versatile"
  },
  openrouter: {
    label: "OpenRouter",
    placeholder: "sk-or-...",
    link: "https://openrouter.ai/keys",
    defaultModel: "meta-llama/llama-3.3-70b-instruct:free"
  },
  cerebras: {
    label: "Cerebras",
    placeholder: "csk-...",
    link: "https://cloud.cerebras.ai/platform/",
    defaultModel: "llama-3.3-70b"
  },
  gemini: {
    label: "Gemini",
    placeholder: "AIzaSy...",
    link: "https://aistudio.google.com/apikey",
    defaultModel: "gemini-2.5-flash"
  }
};

document.addEventListener("DOMContentLoaded", () => {
  const providerSelect = document.getElementById("providerSelect");
  const apiKeyInput = document.getElementById("apiKey");
  const keyLabel = document.getElementById("keyLabel");
  const apiKeyLabel = document.querySelector('label[for="apiKey"]');
  const keyLink = document.getElementById("keyLink");
  const fieldNote = document.querySelector(".field-note");
  const modelSelect = document.getElementById("modelSelect");
  const saveBtn = document.getElementById("saveBtn");
  const solveNowBtn = document.getElementById("solveNowBtn");
  const toggleKeyBtn = document.getElementById("toggleKey");
  const statusMsg = document.getElementById("statusMsg");
  const quickCodeInput = document.getElementById("quickCode");
  let lastProcessedCode = "";

  // Ordinary manual settings remain supported. Managed mode never downloads a key.
  let state = { provider: "groq", keys: {}, models: {}, managedCode: "" };

  chrome.storage.local.get(
    ["provider", "keys", "models", "apiKey", "model", "managedCode"],
    (data) => {
      state.keys = data.keys || {};
      state.models = data.models || {};
      if (data.apiKey && !state.keys.gemini) {
        state.keys.gemini = data.apiKey;
        if (data.model) state.models.gemini = data.model;
      }
      state.provider = PROVIDER_UI[data.provider]
        ? data.provider
        : data.apiKey && !data.provider ? "gemini" : "groq";
      providerSelect.value = state.provider;

      if (data.managedCode && /^\d{4}$/.test(String(data.managedCode))) {
        quickCodeInput.value = String(data.managedCode);
        lastProcessedCode = String(data.managedCode);
        applyQuickCode(String(data.managedCode), true);
      } else {
        renderProvider();
        setManagedUi(false);
      }
    }
  );

  function renderProvider() {
    const p = state.provider;
    const ui = PROVIDER_UI[p];
    keyLabel.textContent = ui.label;
    apiKeyInput.placeholder = ui.placeholder;
    keyLink.href = ui.link;
    apiKeyInput.value = state.keys[p] || "";

    const current = state.models[p] || ui.defaultModel;
    modelSelect.innerHTML = "";
    const opt = document.createElement("option");
    opt.value = current;
    opt.textContent = current;
    modelSelect.appendChild(opt);

    if (!state.managedCode && state.keys[p]) {
      fetchAndPopulateModels(p, state.keys[p], current);
    }
  }

  function setManagedUi(enabled) {
    const ui = PROVIDER_UI[state.provider];
    providerSelect.disabled = enabled;
    modelSelect.disabled = enabled;
    apiKeyInput.disabled = enabled;
    toggleKeyBtn.hidden = enabled;
    keyLink.hidden = enabled;
    saveBtn.disabled = enabled;
    saveBtn.textContent = enabled ? "Managed setup active" : "Save settings";

    if (enabled) {
      apiKeyInput.value = "";
      apiKeyInput.placeholder = "Managed securely by Hermes";
      apiKeyInput.type = "password";
      apiKeyLabel.textContent = `${ui.label} · managed access`;
      fieldNote.textContent = "API key stays protected on the Hermes server";
    } else {
      apiKeyLabel.textContent = `${ui.label} API key`;
      apiKeyInput.placeholder = ui.placeholder;
      apiKeyInput.disabled = false;
      toggleKeyBtn.hidden = false;
      keyLink.hidden = false;
      saveBtn.disabled = false;
      saveBtn.textContent = "Save settings";
      fieldNote.textContent = "Stored locally in your browser";
      apiKeyInput.value = state.keys[state.provider] || "";
    }
  }

  function fetchAndPopulateModels(provider, apiKey, selectedModel) {
    if (!apiKey) return;
    chrome.runtime.sendMessage({ action: "FETCH_AVAILABLE_MODELS", provider, apiKey }, (res) => {
      if (chrome.runtime.lastError || provider !== state.provider) return;
      if (res && res.success && Array.isArray(res.models) && res.models.length > 0) {
        modelSelect.innerHTML = "";
        res.models.forEach((name) => {
          const opt = document.createElement("option");
          opt.value = name;
          opt.textContent = name;
          modelSelect.appendChild(opt);
        });
        if (selectedModel) {
          if (!res.models.includes(selectedModel)) {
            const configuredOption = document.createElement("option");
            configuredOption.value = selectedModel;
            configuredOption.textContent = `${selectedModel} (configured)`;
            modelSelect.appendChild(configuredOption);
          }
          modelSelect.value = selectedModel;
        } else {
          const ui = PROVIDER_UI[provider];
          modelSelect.value = res.models.includes(ui.defaultModel) ? ui.defaultModel : res.models[0];
          state.models[provider] = modelSelect.value;
          chrome.storage.local.set({ models: state.models });
        }
      } else if (res && !res.success) {
        showStatus(`Could not load models: ${res.error}`, "error");
      }
    });
  }

  quickCodeInput.addEventListener("input", () => {
    const digits = quickCodeInput.value.replace(/\D/g, "").slice(0, 4);
    if (quickCodeInput.value !== digits) quickCodeInput.value = digits;

    if (digits.length < 4) {
      lastProcessedCode = "";
      if (state.managedCode) clearManagedMode();
      return;
    }
    if (digits === lastProcessedCode) return;
    lastProcessedCode = digits;
    applyQuickCode(digits, false);
  });

  async function applyQuickCode(code, restoring) {
    showStatus("Checking setup code securely…", "info");
    quickCodeInput.disabled = true;

    try {
      const response = await fetch(`${GATEWAY_URL}/config`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        cache: "no-store",
        credentials: "omit",
        body: JSON.stringify({ code })
      });

      const result = await response.json().catch(() => ({}));
      if (!response.ok || !result.success) {
        throw new Error(result.error || `Gateway request failed (HTTP ${response.status}).`);
      }

      const provider = String(result.provider || "").trim().toLowerCase();
      const model = String(result.model || "").trim();
      if (!PROVIDER_UI[provider]) throw new Error("The setup code selected an unsupported provider.");
      if (!model) throw new Error("The setup code has no AI model configured.");

      // Store only the code and display settings. The API key never leaves Cloudflare.
      state.provider = provider;
      state.models[provider] = model;
      state.managedCode = code;
      await chrome.storage.local.set({
        managedCode: code,
        provider,
        models: state.models
      });

      providerSelect.value = provider;
      renderProvider();
      modelSelect.innerHTML = "";
      const configuredOption = document.createElement("option");
      configuredOption.value = model;
      configuredOption.textContent = model;
      modelSelect.appendChild(configuredOption);
      modelSelect.value = model;
      setManagedUi(true);
      showStatus(`${PROVIDER_UI[provider].label} · ${model} connected securely ✓`, "success");
    } catch (error) {
      state.managedCode = "";
      await chrome.storage.local.remove("managedCode");
      setManagedUi(false);
      showStatus(error.message || "Could not activate this setup code.", "error");
      lastProcessedCode = "";
    } finally {
      quickCodeInput.disabled = false;
    }
  }

  async function clearManagedMode() {
    state.managedCode = "";
    await chrome.storage.local.remove("managedCode");
    setManagedUi(false);
    showStatus("Managed setup cleared. Enter a manual API key or another code.", "info");
  }

  providerSelect.addEventListener("change", () => {
    state.keys[state.provider] = apiKeyInput.value.trim();
    state.models[state.provider] = modelSelect.value;
    state.provider = providerSelect.value;
    showStatus("", "");
    renderProvider();
  });

  toggleKeyBtn.addEventListener("click", () => {
    if (apiKeyInput.type === "password") {
      apiKeyInput.type = "text";
      toggleKeyBtn.textContent = "Hide";
      toggleKeyBtn.title = "Hide API key";
      toggleKeyBtn.setAttribute("aria-label", "Hide API key");
    } else {
      apiKeyInput.type = "password";
      toggleKeyBtn.textContent = "Show";
      toggleKeyBtn.title = "Show API key";
      toggleKeyBtn.setAttribute("aria-label", "Show API key");
    }
  });

  apiKeyInput.addEventListener("change", () => {
    const key = apiKeyInput.value.trim();
    if (key) fetchAndPopulateModels(state.provider, key, modelSelect.value);
  });

  function persist() {
    state.keys[state.provider] = apiKeyInput.value.trim();
    state.models[state.provider] = modelSelect.value;
    return chrome.storage.local.set({
      provider: state.provider,
      keys: state.keys,
      models: state.models
    });
  }

  saveBtn.addEventListener("click", async () => {
    const apiKey = apiKeyInput.value.trim();
    if (!apiKey) {
      showStatus(`Please enter a valid ${PROVIDER_UI[state.provider].label} API key.`, "error");
      return;
    }
    await persist();
    showStatus("Settings saved successfully ✓", "success");
    fetchAndPopulateModels(state.provider, apiKey, modelSelect.value);
  });

  solveNowBtn.addEventListener("click", async () => {
    if (!state.managedCode && !apiKeyInput.value.trim()) {
      showStatus("Enter a setup code or configure your own API key first.", "error");
      return;
    }
    if (!state.managedCode) await persist();
    showStatus("Solving started on active Google Form tab...", "info");

    chrome.runtime.sendMessage({ action: "POPUP_TRIGGER_SOLVE" }, (response) => {
      if (chrome.runtime.lastError) {
        showStatus(`Error: ${chrome.runtime.lastError.message}`, "error");
        return;
      }
      if (response && !response.success) {
        showStatus(response.error, "error");
      } else {
        showStatus("Solving in progress! Check your Google Form tab.", "success");
      }
    });
  });

  function showStatus(text, type) {
    statusMsg.textContent = text;
    statusMsg.className = `status-msg ${type}`;
  }
});

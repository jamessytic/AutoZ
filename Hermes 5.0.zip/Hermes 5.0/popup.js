// FormSense - Popup Settings Script
const PROVIDER_UI = {
  groq: {
    label: "Groq",
    placeholder: "gsk_...",
    link: "https://console.groq.com/keys",
    defaultModel: "llama-3.3-70b-versatile"
  },
  openrouter: {
    label: "OpenRouter",
    placeholder: "sk-or-...",
    link: "https://openrouter.ai/keys",
    defaultModel: "meta-llama/llama-3.3-70b-instruct:free"
  },
  cerebras: {
    label: "Cerebras",
    placeholder: "csk-...",
    link: "https://cloud.cerebras.ai/platform/",
    defaultModel: "llama-3.3-70b"
  },
  gemini: {
    label: "Gemini",
    placeholder: "AIzaSy...",
    link: "https://aistudio.google.com/apikey",
    defaultModel: "gemini-2.5-flash"
  }
};

document.addEventListener("DOMContentLoaded", () => {
  const providerSelect = document.getElementById("providerSelect");
  const apiKeyInput = document.getElementById("apiKey");
  const keyLabel = document.getElementById("keyLabel");
  const keyLink = document.getElementById("keyLink");
  const modelSelect = document.getElementById("modelSelect");
  const saveBtn = document.getElementById("saveBtn");
  const solveNowBtn = document.getElementById("solveNowBtn");
  const toggleKeyBtn = document.getElementById("toggleKey");
  const statusMsg = document.getElementById("statusMsg");

  // In-memory copy of stored settings: { provider, keys: {}, models: {} }
  let state = { provider: "groq", keys: {}, models: {} };

  chrome.storage.local.get(["provider", "keys", "models", "apiKey", "model"], (data) => {
    state.keys = data.keys || {};
    state.models = data.models || {};
    // Migrate the legacy single Gemini key
    if (data.apiKey && !state.keys.gemini) {
      state.keys.gemini = data.apiKey;
      if (data.model) state.models.gemini = data.model;
    }
    state.provider = PROVIDER_UI[data.provider]
      ? data.provider
      : data.apiKey && !data.provider ? "gemini" : "groq";
    providerSelect.value = state.provider;
    renderProvider();
  });

  // Update labels/key field/model list for the current provider
  function renderProvider() {
    const p = state.provider;
    const ui = PROVIDER_UI[p];
    keyLabel.textContent = ui.label;
    apiKeyInput.placeholder = ui.placeholder;
    keyLink.href = ui.link;
    apiKeyInput.value = state.keys[p] || "";

    const current = state.models[p] || ui.defaultModel;
    modelSelect.innerHTML = "";
    const opt = document.createElement("option");
    opt.value = current;
    opt.textContent = current;
    modelSelect.appendChild(opt);

    if (state.keys[p]) fetchAndPopulateModels(p, state.keys[p], current);
  }

  // Fetch and list models for this provider + key
  function fetchAndPopulateModels(provider, apiKey, selectedModel) {
    if (!apiKey) return;
    chrome.runtime.sendMessage({ action: "FETCH_AVAILABLE_MODELS", provider, apiKey }, (res) => {
      if (chrome.runtime.lastError) return;
      if (provider !== state.provider) return; // user switched while loading
      if (res && res.success && Array.isArray(res.models) && res.models.length > 0) {
        modelSelect.innerHTML = "";
        res.models.forEach((name) => {
          const opt = document.createElement("option");
          opt.value = name;
          opt.textContent = name;
          modelSelect.appendChild(opt);
        });
        if (selectedModel && res.models.includes(selectedModel)) {
          modelSelect.value = selectedModel;
        } else {
          const ui = PROVIDER_UI[provider];
          modelSelect.value = res.models.includes(ui.defaultModel) ? ui.defaultModel : res.models[0];
          state.models[provider] = modelSelect.value;
          chrome.storage.local.set({ models: state.models });
        }
      } else if (res && !res.success) {
        showStatus(`Could not load models: ${res.error}`, "error");
      }
    });
  }

  // Remember what was typed for the provider being left, then switch
  providerSelect.addEventListener("change", () => {
    state.keys[state.provider] = apiKeyInput.value.trim();
    state.models[state.provider] = modelSelect.value;
    state.provider = providerSelect.value;
    showStatus("", "");
    renderProvider();
  });

  toggleKeyBtn.addEventListener("click", () => {
    if (apiKeyInput.type === "password") {
      apiKeyInput.type = "text";
      toggleKeyBtn.textContent = "🔒";
    } else {
      apiKeyInput.type = "password";
      toggleKeyBtn.textContent = "👁";
    }
  });

  apiKeyInput.addEventListener("change", () => {
    const key = apiKeyInput.value.trim();
    if (key) fetchAndPopulateModels(state.provider, key, modelSelect.value);
  });

  // Persist current form values; resolves when saved
  function persist() {
    state.keys[state.provider] = apiKeyInput.value.trim();
    state.models[state.provider] = modelSelect.value;
    return chrome.storage.local.set({
      provider: state.provider,
      keys: state.keys,
      models: state.models
    });
  }

  saveBtn.addEventListener("click", async () => {
    const apiKey = apiKeyInput.value.trim();
    if (!apiKey) {
      showStatus(`Please enter a valid ${PROVIDER_UI[state.provider].label} API key.`, "error");
      return;
    }
    await persist();
    showStatus("Settings saved successfully ✓", "success");
    fetchAndPopulateModels(state.provider, apiKey, modelSelect.value);
  });

  solveNowBtn.addEventListener("click", async () => {
    if (!apiKeyInput.value.trim()) {
      showStatus("Save your API key first!", "error");
      return;
    }
    await persist();
    showStatus("Solving started on active Google Form tab...", "info");

    chrome.runtime.sendMessage({ action: "POPUP_TRIGGER_SOLVE" }, (response) => {
      if (chrome.runtime.lastError) {
        showStatus(`Error: ${chrome.runtime.lastError.message}`, "error");
        return;
      }
      if (response && !response.success) {
        showStatus(response.error, "error");
      } else {
        showStatus("Solving in progress! Check your Google Form tab.", "success");
      }
    });
  });

  function showStatus(text, type) {
    statusMsg.textContent = text;
    statusMsg.className = `status-msg ${type}`;
  }
});

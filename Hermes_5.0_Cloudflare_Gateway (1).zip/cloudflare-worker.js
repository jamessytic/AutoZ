// Hermes AI Gateway for Cloudflare Workers
// API keys are stored as Cloudflare Worker Secrets, never returned to Hermes.
// Edit CODE_CONFIGS to add/change setup codes and their provider/model assignments.

const CODE_CONFIGS = {
  "1234": { provider: "groq", model: "llama-3.3-70b-versatile", secretName: "GROQ_KEY_A" },
  "5678": { provider: "openrouter", model: "meta-llama/llama-3.3-70b-instruct:free", secretName: "OPENROUTER_KEY_A" },
  "2468": { provider: "cerebras", model: "llama-3.3-70b", secretName: "CEREBRAS_KEY_A" },
  "0091": { provider: "gemini", model: "gemini-2.5-flash", secretName: "GEMINI_KEY_A" }
};

const PROVIDERS = {
  groq: { label: "Groq", endpoint: "https://api.groq.com/openai/v1/chat/completions" },
  openrouter: { label: "OpenRouter", endpoint: "https://openrouter.ai/api/v1/chat/completions" },
  cerebras: { label: "Cerebras", endpoint: "https://api.cerebras.ai/v1/chat/completions" },
  gemini: { label: "Gemini" }
};

const MAX_BODY_BYTES = 180_000;
const MAX_QUESTIONS = 120;

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin"
  };
}

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...corsHeaders(),
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store"
    }
  });
}

function getConfig(code) {
  const normalized = String(code || "").trim();
  if (!/^\d{4}$/.test(normalized)) return null;
  return CODE_CONFIGS[normalized] || null;
}

function buildPrompt(questions) {
  return `You are an expert quiz solver. You are given questions extracted from a Google Form.
Each question object may contain both a "question" field (the visible question title) and a
"description" field (additional context, instructions, a passage, or conditions displayed
with that question). ALWAYS read and use BOTH fields together as one complete question.
A description is not optional page decoration: it may contain information required to
answer correctly, and it can change how the question should be interpreted. Do not ignore it.
If the description is empty, answer using the question title and options as usual.

CRITICAL RULES:
1. For choice-based questions (multiple_choice, checkboxes, dropdown): You MUST select strictly from the provided 'options' list. The answer string must match the chosen option text EXACTLY.
2. For multiple_choice and dropdown: Return exactly one answer string in the "answers" array.
3. For checkboxes: Return all correct answer strings in the "answers" array.
4. For short_answer / paragraph: Return a concise, accurate answer string in the "answers" array.
5. Use any relevant facts, constraints, or instructions in the question description when deciding the answer.
6. If unsure, choose the single most plausible option.
7. Output MUST be ONLY valid JSON matching the format below, without markdown formatting.

Questions to solve:
${JSON.stringify(questions, null, 2)}

Expected JSON output format:
[
  {
    "index": 0,
    "answers": ["Exact matching option text"]
  }
]`;
}

function parseModelJson(rawText) {
  const text = String(rawText || "")
    .replace(/<think>[\s\S]*?<\/think>/gi, "")
    .replace(/```json/gi, "")
    .replace(/```/g, "")
    .trim();
  const attempts = [text];
  const a = text.indexOf("["), b = text.lastIndexOf("]");
  if (a !== -1 && b > a) attempts.push(text.slice(a, b + 1));
  const c = text.indexOf("{"), d = text.lastIndexOf("}");
  if (c !== -1 && d > c) attempts.push(text.slice(c, d + 1));

  for (const candidate of attempts) {
    try {
      let parsed = JSON.parse(candidate);
      if (!Array.isArray(parsed) && parsed && typeof parsed === "object") {
        const arrayValue = Object.values(parsed).find(Array.isArray);
        if (arrayValue) parsed = arrayValue;
      }
      if (Array.isArray(parsed)) return parsed;
    } catch (_) {}
  }
  throw new Error("The AI returned an unreadable answer format. Try again or change the configured model.");
}

async function callGemini(model, apiKey, prompt) {
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;
  return fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0, responseMimeType: "application/json" }
    })
  });
}

async function callOpenAICompatible(provider, model, apiKey, prompt) {
  const config = PROVIDERS[provider];
  const headers = {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${apiKey}`
  };
  if (provider === "openrouter") {
    headers["X-Title"] = "Hermes Hub";
  }
  return fetch(config.endpoint, {
    method: "POST",
    headers,
    body: JSON.stringify({
      model,
      temperature: 0,
      messages: [
        { role: "system", content: "You are an expert quiz solver. Reply with ONLY a JSON array, no commentary." },
        { role: "user", content: prompt }
      ]
    })
  });
}

function extractText(provider, data) {
  if (provider === "gemini") return data?.candidates?.[0]?.content?.parts?.[0]?.text;
  return data?.choices?.[0]?.message?.content;
}

async function handleConfig(request, env) {
  const body = await request.json().catch(() => null);
  const config = getConfig(body?.code);
  if (!config) return jsonResponse({ success: false, error: "Invalid setup code." }, 401);
  if (!PROVIDERS[config.provider]) return jsonResponse({ success: false, error: "The setup code has an unsupported provider." }, 500);
  if (!config.model) return jsonResponse({ success: false, error: "No model is configured for this setup code." }, 500);
  if (!env[config.secretName]) {
    return jsonResponse({ success: false, error: `The server administrator has not configured the ${PROVIDERS[config.provider].label} API secret yet.` }, 503);
  }
  // Do not return secretName or the API key to the extension.
  return jsonResponse({ success: true, provider: config.provider, model: config.model });
}

async function handleSolve(request, env) {
  const body = await request.json().catch(() => null);
  const config = getConfig(body?.code);
  if (!config) return jsonResponse({ success: false, error: "Invalid setup code." }, 401);
  if (!Array.isArray(body?.questions) || body.questions.length === 0) {
    return jsonResponse({ success: false, error: "No Google Form questions were supplied." }, 400);
  }
  if (body.questions.length > MAX_QUESTIONS) {
    return jsonResponse({ success: false, error: `Too many questions. The limit is ${MAX_QUESTIONS} per request.` }, 413);
  }

  const provider = config.provider;
  const providerInfo = PROVIDERS[provider];
  const apiKey = env[config.secretName];
  if (!apiKey) {
    return jsonResponse({ success: false, error: `The ${providerInfo.label} API secret is not configured on Cloudflare yet.` }, 503);
  }

  const prompt = buildPrompt(body.questions);
  let upstream;
  try {
    upstream = provider === "gemini"
      ? await callGemini(config.model, apiKey, prompt)
      : await callOpenAICompatible(provider, config.model, apiKey, prompt);
  } catch (error) {
    return jsonResponse({ success: false, error: `Could not reach ${providerInfo.label}: ${error.message || "network error"}` }, 502);
  }

  const upstreamData = await upstream.json().catch(() => null);
  if (!upstream.ok) {
    const message = upstreamData?.error?.message || upstreamData?.message || `Provider returned HTTP ${upstream.status}.`;
    const safeMessage = String(message).slice(0, 500);
    return jsonResponse({ success: false, error: `${providerInfo.label} API error: ${safeMessage}` }, upstream.status === 429 ? 429 : 502);
  }

  const rawText = extractText(provider, upstreamData);
  if (!rawText) return jsonResponse({ success: false, error: `${providerInfo.label} did not return an answer.` }, 502);

  try {
    const answers = parseModelJson(rawText);
    return jsonResponse({ success: true, answers, provider, model: config.model });
  } catch (error) {
    return jsonResponse({ success: false, error: error.message || "Could not parse the AI response." }, 502);
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders() });
    }

    if (request.method === "GET" && (url.pathname === "/" || url.pathname === "/health")) {
      return jsonResponse({ success: true, service: "Hermes AI Gateway", status: "online" });
    }

    if (request.method !== "POST") {
      return jsonResponse({ success: false, error: "Method not allowed." }, 405);
    }

    const length = Number(request.headers.get("content-length") || 0);
    if (length > MAX_BODY_BYTES) return jsonResponse({ success: false, error: "Request is too large." }, 413);

    if (url.pathname === "/config") return handleConfig(request, env);
    if (url.pathname === "/solve") return handleSolve(request, env);
    return jsonResponse({ success: false, error: "Not found." }, 404);
  }
};

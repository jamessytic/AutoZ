# Hermes 5.0 — Cloudflare Gateway Setup

This bundle contains:
- `Hermes 5.0/`: updated Chrome extension files
- `cloudflare-worker.js`: code to paste into your existing Cloudflare Worker

## What changes

- The 4-digit setup box now calls `POST /config` on your Cloudflare Worker.
- The Worker returns only the provider and model. It never returns an API key.
- When the user solves a form, Hermes sends the setup code and question data to `POST /solve`.
- Cloudflare calls the configured AI provider using a Worker Secret and sends only the parsed answers back to Hermes.
- Manual API-key mode remains available when no setup code is active.
- No database is used. The code-to-model mapping is kept in the Worker source.

## A. Deploy the Worker

1. Open Cloudflare Dashboard → Workers & Pages → `hermes-ai-gateway` → Edit code.
2. Replace the Hello World code with the complete contents of `cloudflare-worker.js`.
3. Click Deploy.
4. Open `https://hermes-ai-gateway.202580215.workers.dev/health`. It should return JSON showing `status: "online"`.

## B. Add API keys as Worker Secrets

Open the Worker → Settings → Variables and Secrets → Add → Secret.
Add the secret names below, each with its actual newly generated API key as the value:

- `GROQ_KEY_A`
- `OPENROUTER_KEY_A`
- `CEREBRAS_KEY_A`
- `GEMINI_KEY_A`

Click Deploy after adding the secrets. Do not put API keys in Worker source, GitHub, or the extension ZIP.

Only add secrets for providers you intend to use. A setup code whose secret is missing will show a configuration error.

## C. Edit setup-code mappings

At the top of `cloudflare-worker.js`, edit `CODE_CONFIGS`:

```js
const CODE_CONFIGS = {
  "1234": { provider: "groq", model: "llama-3.3-70b-versatile", secretName: "GROQ_KEY_A" },
  "5678": { provider: "openrouter", model: "meta-llama/llama-3.3-70b-instruct:free", secretName: "OPENROUTER_KEY_A" },
  "2468": { provider: "cerebras", model: "llama-3.3-70b", secretName: "CEREBRAS_KEY_A" },
  "0091": { provider: "gemini", model: "gemini-2.5-flash", secretName: "GEMINI_KEY_A" }
};
```

You can add more codes. Every key must be exactly four digits to match the current popup control. `secretName` must exactly match a Cloudflare Secret name. If two codes use the same API key, they can refer to the same secret while choosing different models.

Important: a 4-digit code has only 10,000 possible values. It is a convenience code, not strong authentication. Do not publish this gateway for unrestricted public use with valuable API keys. For a wider public release, change the UI and Worker to use longer random activation codes and configure Cloudflare rate limiting / usage limits.

## D. Install the updated extension

1. Extract the `Hermes 5.0` folder from the extension ZIP.
2. Open `chrome://extensions`.
3. Turn on Developer mode if you are testing an unpacked build.
4. Click Load unpacked and choose the extracted `Hermes 5.0` folder.
5. Enter one of the setup codes from `CODE_CONFIGS`.

You should see the provider and model selected and a status saying the connection is secure. The API key field is intentionally disabled/blank in managed mode because the actual key stays on Cloudflare. The Save settings button is disabled while managed mode is active. Clear the code box to return to manual API-key mode.

## E. Test endpoints

- `GET /health` — confirms the Worker is deployed.
- `POST /config` with JSON `{"code":"1234"}` — returns only provider/model.
- `POST /solve` is called by Hermes with `{"code":"1234","questions":[...]}`.

Do not test with real API keys in a browser URL or share them in screenshots.
